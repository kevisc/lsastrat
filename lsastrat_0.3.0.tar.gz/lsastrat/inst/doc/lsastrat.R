## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## ----setup--------------------------------------------------------------------
library(lsastrat)
data(pisa_mini)

## ----reps---------------------------------------------------------------------
reps <- paste0("W_FSTURWT", 1:64)
math <- paste0("PV", 1:10, "MATH")

## ----gradient-----------------------------------------------------------------
g <- social_gradient(pisa_mini, achievement = math, escs = "ESCS",
                     weight = "W_FSTUWT", repweights = reps)
g

## ----gradient-methods---------------------------------------------------------
coef(g)
confint(g)

## ----gradient-plot, fig.width = 6, fig.height = 4-----------------------------
plot(g)

## ----seg-social---------------------------------------------------------------
segregation_index(pisa_mini, unit = "school_id", group = "IMMIG",
                  weight = "W_FSTUWT", variance = "bootstrap",
                  n_boot = 99, boot_seed = 1)

## ----seg-rep------------------------------------------------------------------
segregation_index(pisa_mini, unit = "school_id", group = "IMMIG",
                  weight = "W_FSTUWT", repweights = reps,
                  indices = c("D", "H", "M"))

## ----seg-academic-------------------------------------------------------------
segregation_index(pisa_mini, unit = "school_id", achievement = math,
                  cutoff = 480, indices = c("D", "H"),
                  variance = "bootstrap", n_boot = 99, boot_seed = 1)

## ----ieop---------------------------------------------------------------------
ieop(pisa_mini, achievement = math,
     circumstances = c("IMMIG", "parental_edu", "books"),
     weight = "W_FSTUWT", repweights = reps)

## ----by-----------------------------------------------------------------------
by_imm <- lsa_by(pisa_mini, by = "IMMIG", estimator = social_gradient,
                 achievement = math, escs = "ESCS", weight = "W_FSTUWT",
                 repweights = reps)
by_imm

## ----vardecomp----------------------------------------------------------------
variance_decomposition(pisa_mini, math, unit = "school_id",
                       weight = "W_FSTUWT", repweights = reps)

## ----ieopdecomp---------------------------------------------------------------
ieop_decompose(pisa_mini, math,
               circumstances = c("IMMIG", "parental_edu", "books"),
               weight = "W_FSTUWT", repweights = reps)

## ----oaxaca-------------------------------------------------------------------
d2 <- pisa_mini[pisa_mini$IMMIG %in% c("native", "first_gen"), ]
d2$IMMIG <- factor(d2$IMMIG)
oaxaca_gap(d2, math, group = "IMMIG",
           predictors = c("ESCS", "books", "parental_edu"),
           weight = "W_FSTUWT", repweights = reps)

## ----multiverse---------------------------------------------------------------
des <- lsa_design(weight = "W_FSTUWT", repweights = reps)
mv <- lsa_multiverse(
  pisa_mini, estimator = social_gradient,
  grid = list(
    achievement = list(math = math, read = paste0("PV", 1:10, "READ")),
    curvature = list(linear = FALSE, quadratic = TRUE)
  ),
  fixed = list(escs = "ESCS"), design = des, term = "slope")
mv

## ----lsa-model----------------------------------------------------------------
lsa_model(pisa_mini, ~ ESCS + IMMIG + female, achievement = math, design = des)

## ----lsa-trend----------------------------------------------------------------
half <- nrow(pisa_mini) %/% 2
c1 <- social_gradient(pisa_mini[1:half, ], math, "ESCS", design = des)
c2 <- social_gradient(pisa_mini[-(1:half), ], math, "ESCS", design = des)
lsa_trend(list("2018" = c1, "2022" = c2), term = "slope", link_error = 3.5)

